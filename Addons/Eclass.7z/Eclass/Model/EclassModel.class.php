<?php

namespace Addons\Eclass\Model;
use Think\Model;

/**
 * Eclass模型
 */
class EclassModel extends Model{
    
}
