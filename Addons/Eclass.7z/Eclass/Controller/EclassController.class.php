<?php

namespace Addons\Eclass\Controller;
use Home\Controller\AddonsController;

class EclassController extends AddonsController{
    public function find(){
        $this->display();
    }

    public function eclass(){
        $rs=curl_init();
        //post提交
        //对教学楼转码
        $zhou=$_POST['zhou'];
        $jie=$_POST['jie'];
        $xingqi=$_POST['xingqi'];
        $jxlm=$_POST['jxlm'];
        $jxlm = iconv("utf-8", "gbk", $jxlm);
        $url="http://jwc.hpu.edu.cn/jscxxt/kong1.jsp";
        $post="zhou=".$zhou."25&xingqi=".$xingqi."&jie=".$jie."&jxlm=".$jxlm; 
        curl_setopt($rs,CURLOPT_URL,$url);
        //post数据来源
        curl_setopt($rs,CURLOPT_REFERER,"http://jwc.hpu.edu.cn/jscxxt/kong.jsp");
        curl_setopt($rs,CURLOPT_POST,1);
        curl_setopt($rs,CURLOPT_POSTFIELDS,$post);
        //设置cookie
        curl_setopt($rs,CURLOPT_COOKIESESSION,1);
        curl_setopt($rs,CURLOPT_COOKIEFILE,"cookie");
        curl_setopt($rs,CURLOPT_COOKIEJAR, "cookie");
        curl_setopt($rs,CURLOPT_COOKIE,session_name().'='.session_id());
        curl_setopt($rs,CURLOPT_RETURNTRANSFER,1);
        curl_setopt($rs,CURLOPT_FOLLOWLOCATION,1);
        //跳转到数据页
        curl_exec($rs);
        curl_setopt($rs,CURLOPT_URL,"http://jwc.hpu.edu.cn/jscxxt/kong1.jsp");
        curl_setopt($rs,CURLOPT_RETURNTRANSFER,1);
        $content=curl_exec($rs);
        curl_close($rs);
        $content = iconv("gbk", "utf-8", $content);
        //echo $content;
        $html=new SimpleHtmlController();
        $html->load($content);
        $table=$html->find('table')[0];
        $arr=$this->get_td_array($table);//执行函数
        $con=count($arr);
        $this->assign('con',$con);
        $this->assign('arr',$arr);
        $this->display();
    }

    //正则匹配表格
    public function get_td_array($table) { 
        $table = preg_replace("'<table[^>]*?>'si","",$table); 
        $table = preg_replace("'<tr[^>]*?>'si","",$table); 
        $table = preg_replace("'<td[^>]*?>'si","",$table); 
        $table = str_replace("</tr>","{tr}",$table); 
        //PHP开源代码
        $table = str_replace("</td>","{td}",$table); 
        //去掉 HTML 标记  
        $table = preg_replace("'<[/!]*?[^<>]*?>'si","",$table); 
        //去掉空白字符   
        $table = preg_replace("'([rn])[s]+'","",$table); 
        $table = str_replace(" ","",$table); 
        $table = str_replace("&nbsp;","",$table); 
        $table = str_replace(" ","",$table);
        $table = explode('{tr}', $table); 
        array_pop($table);  
        foreach ($table as $key=>$tr) { 
            $td = explode('{td}', $tr); 
            array_pop($td); 
            $td_array[] = $td; 
        } 
        return $td_array; 
}
}
