<?php

namespace Addons\Kclass\Model;
use Home\Model;

/**
 * Class模型
 */
class KclassModel extends Model{

}
