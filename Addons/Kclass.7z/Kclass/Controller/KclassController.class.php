<?php

namespace Addons\Kclass\Controller;
use Home\Controller\AddonsController;

class KclassController extends AddonsController{
    public function verify(){
    	//获取到cookie和验证码并保存cookie
    	$snoopy = new SnoopyController();
        $snoopy->fetch('http://www.schoolhand.top/index.php/Kongxianjiaoshi/index/useropenid/oG6xVw4hIOhSMaFgy2r7BlrOcgx0'); //获取所有内容
        $cookies=$snoopy->headers;
        preg_match('/Set-Cookie:(.*);/iU',$cookies[6],$cookies); //正则匹配  
        $cookie=$cookies[1];
        $arr=explode('=', $cookie);
        setcookie($arr[0],$arr[1]);

        $snoopy->referer='http://www.schoolhand.top/index.php/Kongxianjiaoshi/index/useropenid/oG6xVw4hIOhSMaFgy2r7BlrOcgx0';
        $snoopy->cookies[$arr[0]] = $arr[1];
        $snoopy->fetch('http://www.schoolhand.top/index.php/Kongxianjiaoshi/chaxun?zxZc=4&zxxq=7&zxJc=1&zxJxl=3&useropenid=oG6xVw4hIOhSMaFgy2r7BlrOcgx0');

        //获取验证码
        $snoopy->referer='http://www.schoolhand.top/index.php/Kongxianjiaoshi/chaxun?zxZc=4&zxxq=6&zxJc=1&zxJxl=3&useropenid=oG6xVw4hIOhSMaFgy2r7BlrOcgx0';
        $snoopy->cookies[$arr[0]] = $arr[1];
        $snoopy->fetch('http://www.schoolhand.top/index.php/Jwc/verify/useropenid/oG6xVw4hIOhSMaFgy2r7BlrOcgx0');
        echo $snoopy->results;

    }
	
	public function login(){
		$this->display();
	}

	public function chaxun(){
		if(isset($_COOKIE['PHPSESSID'])){
        	$cookie="PHPSESSID".$_COOKIE['PHPSESSID'];
        	$ch = curl_init ();
        	$url="http://www.schoolhand.top/index.php/Kongxianjiaoshi/login.html?username=".$_POST['zjh']."&password=".$_POST['mm']."&verify=".$_POST['v_yzm']."&useropenid=oG6xVw4hIOhSMaFgy2r7BlrOcgx0&jxl=".$_POST['jxl']."&zhou=".$_POST['zhou']."&week=".$_POST['xingqi']."&jieci=".$_POST['jie'];
	        curl_setopt($ch,CURLOPT_URL,$url);
	        curl_setopt($ch,CURLOPT_REFERER,"http://www.schoolhand.top/index.php/Kongxianjiaoshi/chaxun?zxZc=4&zxxq=6&zxJc=1&zxJxl=3&useropenid=oG6xVw4hIOhSMaFgy2r7BlrOcgx0");
	        curl_setopt($ch, CURLOPT_HEADER, 0);
	        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // 跳过证书检查 
	        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); // 跳过证书检查 
	        curl_setopt($ch,CURLOPT_USERAGENT , "Mozilla/5.0 (Windows NT 6.3; WOW64; rv:42.0) Gecko/20100101 Firefox/42.0");
	        curl_setopt($ch,CURLOPT_COOKIE,"$cookie");
	        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	        $content=curl_exec($ch);
	        curl_close ( $ch );
	        $html=new SimpleHtmlController();
	        $html->load($content);
	        $table=$html->find('table')[0];
	        $arr=$this->get_td_array($table);//执行函数
	        $con=count($arr);
	        $this->assign("con",$con);
	        $this->assign("arr",$arr);  
	        $this->display('class');
		}
	}

	//正则匹配表格
    public function get_td_array($table) { 
        $table = preg_replace("'<table[^>]*?>'si","",$table); 
        $table = preg_replace("'<tr[^>]*?>'si","",$table); 
        $table = preg_replace("'<td[^>]*?>'si","",$table); 
        $table = str_replace("</tr>","{tr}",$table); 
        //PHP开源代码
        $table = str_replace("</td>","{td}",$table); 
        //去掉 HTML 标记  
        $table = preg_replace("'<[/!]*?[^<>]*?>'si","",$table); 
        //去掉空白字符   
        $table = preg_replace("'([rn])[s]+'","",$table); 
        $table = str_replace(" ","",$table); 
        $table = str_replace("&nbsp;","",$table); 
        $table = str_replace(" ","",$table);
        $table = explode('{tr}', $table); 
        array_pop($table);  
        foreach ($table as $key=>$tr) { 
            $td = explode('{td}', $tr); 
            array_pop($td); 
            $td_array[] = $td; 
        } 
        return $td_array; 
    }	
}
