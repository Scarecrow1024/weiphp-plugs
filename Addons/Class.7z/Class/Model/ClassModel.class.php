<?php

namespace Addons\Class\Model;
use Home\Model;

/**
 * Class模型
 */
class ClassModel extends Model{
   
}
